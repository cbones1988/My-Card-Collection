import { StyleSheet } from "react-native";

export const globalOptions = {
  name: "my_card_collection_32634",
  url: "https://my_card_collection_32634.botics.co",
  api: "https://my_card_collection_32634.botics.co/api/v1"
}
export const modulesOptions = {
  "@modules/app-menu": {
    "copy": "Routes available!"
  }
}
